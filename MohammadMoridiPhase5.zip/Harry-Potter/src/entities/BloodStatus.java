package entities;

public enum BloodStatus {
	Muggle, Pure_blood, Half_blood, Muggle_born, Squibb, Part_human, Half_breed
}
