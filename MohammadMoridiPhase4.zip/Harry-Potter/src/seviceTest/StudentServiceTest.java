package seviceTest;

import org.junit.Assert;
import org.junit.Test;

import entities.*;

	public class StudentServiceTest {
		
		@Test
		public void ConstructorTest() {
			Student harry = new Student("Harry Potter");
			
			String actual = harry.getName();
			String expected = "Harry Potter";
			Assert.assertEquals(expected, actual);			
		}		
}
