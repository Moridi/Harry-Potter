package service;

import entities.Course;

public class CourseService {
		private Course course;

		public CourseService(Course course) {
			this.course = course;
		}
		
		
}
