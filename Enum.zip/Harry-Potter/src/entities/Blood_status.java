package entities;

public enum Blood_status {
	Muggle, Pure_blood, Half_blood, Muggle_born, Squibb
}
